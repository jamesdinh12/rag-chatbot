
# THIS FILE IS GENERATED FROM CVXPY SETUP.PY
short_version = '1.4.2'
version = '1.4.2'
full_version = '1.4.2'
git_revision = '5d1416b'
commit_count = '0'
release = True
if not release:
    version = full_version
